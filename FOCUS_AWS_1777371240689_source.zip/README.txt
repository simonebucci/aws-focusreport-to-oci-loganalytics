Content
Sources: [FOCUS_AWS]
Parsers: [FOCUS_AWS]
Fields: [AvailabilityZone, BilledCostD, BillingAccountId, BillingAccountName, BillingAccountType, BillingCurrency, BillingPeriodEndTS, BillingPeriodStartTS, CapacityReservationStatus, Capacity_Reservation_Id, ChargeCategory, ChargeClass, ChargeDescription, ChargeFrequency, ChargePeriodEnd, ChargePeriodStart, CommitmentDiscountCategory, CommitmentDiscountId, CommitmentDiscountName, CommitmentDiscountQuantity, CommitmentDiscountStatus, CommitmentDiscountType, CommitmentDiscountUnit, ConsumedQuantityD, ConsumedUnit, ContractedCostD, ContractedUnitPriceD, EffectiveCostD, InvoiceId, InvoiceIssuerName, ListCostD, ListUnitPriceD, MC_CONSUMPTION, MC_CURRENCY, MC_ENVIRONMENT, MC_Hypervisor, MC_REGION, MC_ResourceName, MC_SERVICE, MC_SKU, MC_USAGE, PricingCategory, PricingCurrency, PricingCurrencyContractedUnitPrice, PricingCurrencyEffectiveCost, PricingCurrencyListUnitPrice, PricingQuantityD, PricingUnit, ProviderName, PublisherName, RegionId, RegionName, ResourceId, ResourceName, ResourceType, ServiceCategory, ServiceName, ServiceSubcategory, SkuMeter, SkuPriceDetails, SkuPriceId, SubAccountId, SubAccountType, TagsMS, skuID, subAccountName, x_Discounts, x_Operation, x_ServiceCode]

Reference
Fields: [mbody]
